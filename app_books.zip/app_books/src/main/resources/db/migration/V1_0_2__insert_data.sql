insert into authors (first_name, last_name) values ('nombre1', 'apellido1');
insert into authors (first_name, last_name) values ('nombre2', 'apellido2');

insert into books (isbn, title, price, author_id) values ('isbn1', 'titulo1', 10.0, 1);
insert into books (isbn, title, price, author_id) values ('isbn2', 'titulo2', 20.0, 1);
insert into books (isbn, title, price, author_id) values ('isbn3', 'titulo3', 30.0, 1);
insert into books (isbn, title, price, author_id) values ('isbn4', 'titulo4', 40.0, 2);
insert into books (isbn, title, price, author_id) values ('isbn5', 'titulo5', 50.0, 2);
