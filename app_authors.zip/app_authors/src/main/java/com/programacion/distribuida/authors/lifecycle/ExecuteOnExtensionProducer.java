//package com.programacion.distribuida.authors.lifecycle;
//
//import io.helidon.microprofile.cdi.ExecuteOnExtension;
//import jakarta.enterprise.context.ApplicationScoped;
//import jakarta.enterprise.inject.Produces;
//
//@ApplicationScoped
//public class ExecuteOnExtensionProducer {
//
//    @Produces
//    @ApplicationScoped
//    public ExecuteOnExtension produceExecuteOnExtension() {
//        return new ExecuteOnExtension();
//    }
//}
